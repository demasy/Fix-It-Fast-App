/**
 * @license
 * Copyright (c) 2014, 2021, Oracle and/or its affiliates.
 * Licensed under The Universal Permissive License (UPL), Version 1.0
 * as shown at https://oss.oracle.com/licenses/upl/
 * @ignore
 */
/**
 * Copyright (c) 2014, 2021, Oracle and/or its affiliates.
 * Licensed under The Universal Permissive License (UPL), Version 1.0
 * as shown at https://oss.oracle.com/licenses/upl/
 */

// offlineController

'use strict';

define(['appConfig', 'persist/persistenceStoreManager', 'persist/pouchDBPersistenceStoreFactory',
        'persist/persistenceManager', 'persist/simpleJsonShredding', 'persist/persistenceUtils',
        'persist/defaultResponseProxy', 'persist/fetchStrategies'],
  function (appConfig, persistenceStoreManager, pouchDBPersistenceStoreFactory,
    persistenceManager, simpleJsonShredding, persistenceUtils, defaultResponseProxy,
    fetchStrategies) {


    function OfflineController(app) {
      var self =this;
      var MBEregex = new RegExp(appConfig.backendName + '/');

      var incidents_request
      var customers_request
      var incidents_stats;
      var incident_request
      var activity_request
      var profile_request

      var tempIncId = 500
      var tempCusId = 500

      persistenceStoreManager.registerDefaultStoreFactory(pouchDBPersistenceStoreFactory);

      function isServerResponseNew(request, serverResponse) {
        return new Promise(function (resolve, reject) {
          persistenceManager.getCache()
            .match(request).then(function (cachedResponse) {
              var serverResPromise = persistenceUtils.responseToJSON(serverResponse);

              // if cached response found in cache
              // compare revNum and decide refreshing UI or not
              if(cachedResponse) {
                var cachedResPromise = persistenceUtils.responseToJSON(cachedResponse);

                Promise.all([cachedResPromise, serverResPromise]).then(function (results) {

                  var cachedRes = JSON.parse(results[0].body.text);
                  var serverRes = JSON.parse(results[1].body.text);

                  resolve(cachedRes.revNum < serverRes.revNum);
                });
              } else {
                resolve(true);
              }
            });
        })
      }

      function addTimeStamp(request, response) {
        // Add timestamp to it if not cached
        return new Promise(function (resolve, reject) {

          if(!persistenceUtils.isCachedResponse(response)) {
            persistenceUtils.responseToJSON(response).then(function (result) {
              if(result.status === 200) {
                var data = JSON.parse(result.body.text);
                data['lastUpdate'] = Date.now();
                persistenceUtils.setResponsePayload(response, data)
                  .then(function (updatedResponse) {
                    persistenceManager.getCache().put(request, updatedResponse.clone())
                      .then(function () {
                        resolve(updatedResponse);
                      });
                  });
              } else {
                resolve(response);
              }
            });
          } else {
            resolve(response);
          }
        });
      }

      var handleOfflineEdit = function(request) {
        if (!persistenceManager.isOnline()) {
          var init = {'status': 503, 'statusText': 'Edit will be processed when online'};
          return Promise.resolve(new Response(null, init));
        } else {
          return persistenceManager.browserFetch(request);
        }
      };

      var defaultIncidentsResponseProxy = defaultResponseProxy.getResponseProxy({
        fetchStrategy: fetchStrategies.getCacheFirstStrategy({
          serverResponseCallback: function(request, response) {
            return new Promise(function (resolve, reject) {
              addTimeStamp(request, response);
              isServerResponseNew(request, response).then(function (result) {
                if(result) {
                  persistenceUtils.responseToJSON(response).then(function (serverRes) {
                    triggerEvent('onIncidentsUpdated', serverRes.body.text);
                  });
                }
                resolve(response);
              }).catch(function (e) {
                reject(e);
              });
            })
          }
        }),
        requestHandlerOverride: {
          handlePost: function (request) {
            if (!persistenceManager.isOnline()) {

              persistenceUtils.requestToJSON(request).then(function (data) {
                // construct incident
                var incident = Object.assign(JSON.parse(data.body.text),
                {
                  "id": 'inc-' + tempIncId++,
                  "status": "open",
                  "createdOn": (new Date(Date.now())).toISOString(),
                  "lastUpdatedOn": "",
                  "_technicianUsername": "hcr",
                  "read": false,
                  "revNum": 0,
                  // TODO construct customer
                  "customer": {
                    "id": "cus-104",
                    "username": "lsmith",
                    "firstName": "Lynn",
                    "lastName": "Smith",
                    "locationId": "loc-4",
                    "mobile": "+16505067000",
                    "home": "+15105552121",
                    "email": "lsmith@somewhere.com",
                    "role": "Customer",
                    "revNum": 1
                  },
                  // TODO construct location
                  "location": {
                    "formattedAddress": "100 Park Street, Alameda, CA 94501 USA",
                    "latitude": "37.763389",
                    "longitude": "-122.243514",
                    "id": "loc-4",
                    "revNum": 1
                  }
                });

                // add this incident to incidents collection cache
                var getIncidentsCachePromise = persistenceManager.getCache().match(incidents_request);
                var getIncidentsStatsCachePromise = persistenceManager.getCache().match(incidents_stats);
                var incidentsCacheRaw;
                var incidentsStatsCacheRaw;
                Promise.all([getIncidentsCachePromise, getIncidentsStatsCachePromise])
                .then(function(promiseValues){
                  incidentsCacheRaw = promiseValues[0];
                  incidentsStatsCacheRaw = promiseValues[1];
                  var incidentsCacheJsonPromise = persistenceUtils.responseToJSON(incidentsCacheRaw);
                  var incidentsStatsCacheJsonPromise = persistenceUtils.responseToJSON(incidentsStatsCacheRaw);
                  return Promise.all([incidentsCacheJsonPromise, incidentsStatsCacheJsonPromise]);
                })
                .then(function(promiseValues) {
                  var incidents = JSON.parse(promiseValues[0].body.text);
                  var incidentsStats = JSON.parse(promiseValues[1].body.text);
                  incidents.result.push(incident);
                  incidents.count++;
                  incidentsStats.incidentCount[incident.priority] += 1;
                  var updateIncidentsPromise = persistenceUtils.setResponsePayload(incidentsCacheRaw, incidents);
                  var updateIncidentsStatsPromise = persistenceUtils.setResponsePayload(incidentsStatsCacheRaw, incidentsStats);
                  return Promise.all([updateIncidentsPromise, updateIncidentsStatsPromise]);
                })
                .then(function(promiseValues) {
                  persistenceManager.getCache().put(incidents_request, promiseValues[0]);
                  persistenceManager.getCache().put(incidents_stats, promiseValues[1]);
                  return;
                }).catch(function(err){
                  if (err) {
                    var errMsg = 'Failed to update Cache with incidents/incident-Stats in offline mode';
                    app.connectionDrawer.showAfterUpdateMessage(errMsg);
                  }
                  // have to handle individual errors
                  // to capture individual errors in chaining, we can resolve with an error
                  // status for each promise and propogate it to the final catch and notify
                  // of propogated error messages.
                });
                // TODO add this incident detail to incident cache

                // TODO construct incident detail response

                // TODO create an empty incident activity cache

              })

              var init = {'status': 503, 'statusText': 'Edit will be processed when online'};
              return Promise.resolve(new Response(null, init));
            } else {
              return persistenceManager.browserFetch(request);
            }
          }
        }
      });

      var defaultIncidentResponseProxy = defaultResponseProxy.getResponseProxy({
        jsonProcessor: {
          shredder: simpleJsonShredding.getShredder('incidents', 'id'),
          unshredder: simpleJsonShredding.getUnshredder()
        },
        fetchStrategy: fetchStrategies.getCacheFirstStrategy({
          serverResponseCallback: function(request, response) {
            return new Promise(function (resolve, reject) {
              isServerResponseNew(request, response).then(function (result) {
                if(result) {
                  persistenceUtils.responseToJSON(response).then(function (serverRes) {
                    triggerEvent('onIncidentUpdated', serverRes.body.text);
                  });
                }
                resolve(response);
              }).catch(function (e) {
                reject(e);
              });
            })

          }
        }),
        requestHandlerOverride: {
          handlePut: handleOfflineEdit
        }
      });

      // default strategy is getCacheIfOfflineStrategy
      var defaultActResponseProxy = defaultResponseProxy.getResponseProxy({
        fetchStrategy: fetchStrategies.getCacheIfOfflineStrategy({
          serverResponseCallback: function(request, response) {
            return new Promise(function(resolve, reject) {
              addTimeStamp(request, response);
              isServerResponseNew(request, response).then(function (result) {
                if(result) {
                  // refresh customer
                  persistenceUtils.responseToJSON(response).then(function (serverRes) {
                    triggerEvent('onActivitiesUpdated', serverRes.body.text);
                  });
                }
                resolve(response);
              }).catch(function (e) {
                reject(e);
              });
            });


          }
        }),
        requestHandlerOverride: {
          handlePost: handleOfflineEdit
        }
      });

      var defaultCustomersResponseProxy = defaultResponseProxy.getResponseProxy({
        fetchStrategy: fetchStrategies.getCacheFirstStrategy({
          serverResponseCallback: function(request, response) {
            return new Promise(function (resolve, reject) {
              isServerResponseNew(request, response).then(function (result) {
                if(result) {
                  // refresh customer
                  persistenceUtils.responseToJSON(response).then(function (serverRes) {
                    triggerEvent('onCustomersUpdated', serverRes.body.text);
                  });
                }
                resolve(response);
              }).catch(function (e) {
                reject(e);
              })
            })

          }
        }),
        requestHandlerOverride: {
          handlePost: function (request) {
            if (!persistenceManager.isOnline()) {
              return new Promise(function (resolve, reject) {
                persistenceUtils.requestToJSON(request).then(function (data) {
                  var customer = Object.assign(
                    {
                      id: 'cus-' + tempCusId++,
                      firstName: null,
                      lastName: null,
                      mobile: null,
                      home: null,
                      email: null,
                      address: {
                        street1: null,
                        street2: null,
                        city: null,
                        state: null,
                        zip: null,
                        country: null
                      }
                    }, JSON.parse(data.body.text));

                  persistenceManager.getCache().match(customers_request).then(function (response) {
                    persistenceUtils.responseToJSON(response).then(function (data) {
                      var customers = JSON.parse(data.body.text)
                      customers.result.push(customer);
                      customers.count++;
                      persistenceUtils.setResponsePayload(response, customers).then(function (response) {
                        persistenceManager.getCache().put(customers_request, response);
                      })
                    })
                  })

                  // TODO create customer detail cache
                  var init = {'status': 503, 'statusText': 'Edit will be processed when online'};
                  resolve(new Response(null, init));
                })
              })

            } else {
              return persistenceManager.browserFetch(request);
            }
          }
        }
      });

      var defaultCustomerResponseProxy = defaultResponseProxy.getResponseProxy({
        jsonProcessor: {
          shredder: simpleJsonShredding.getShredder('customers', 'id'),
          unshredder: simpleJsonShredding.getUnshredder()
        },
        fetchStrategy: fetchStrategies.getCacheFirstStrategy({
          serverResponseCallback: function(request, response) {
            return new Promise(function (resolve, reject) {
              isServerResponseNew(request, response).then(function (result) {
                if(result) {
                  // refresh customer
                  persistenceUtils.responseToJSON(response).then(function (serverRes) {
                    triggerEvent('onCustomerUpdated', serverRes.body.text);
                  });
                }
                resolve(response);
              }).catch(function (e) {
                reject(e);
              })
            })

          }
        }),
        requestHandlerOverride: {
          handlePatch: handleOfflineEdit
        }
      });

      var defaultStatsResponseProxy = defaultResponseProxy.getResponseProxy({
        fetchStrategy: fetchStrategies.getCacheFirstStrategy({
          serverResponseCallback: function(request, response) {
            return new Promise(function (resolve, reject) {
              isServerResponseNew(request, response).then(function (result) {
                if(result) {
                  persistenceUtils.responseToJSON(response).then(function (serverRes) {
                    triggerEvent('onHistoryStatsUpdated', serverRes.body.text);
                  });
                }
                resolve(response);
              }).catch(function (e) {
                reject(e);
              });
            })

          }
        })
      });

      var defaultIncStatsResponseProxy = defaultResponseProxy.getResponseProxy({
        fetchStrategy: fetchStrategies.getCacheFirstStrategy({
          serverResponseCallback: function(request, response) {
            return new Promise(function (resolve, reject) {
              isServerResponseNew(request, response).then(function (result) {
                if(result) {
                  persistenceUtils.responseToJSON(response).then(function (serverRes) {
                    triggerEvent('onIncidentStatsUpdated', serverRes.body.text);
                  });
                }
                resolve(response);
              }).catch(function (e) {
                reject(e);
              });
            })
          }
        })
      });

      var defaultProfileResponseProxy =  defaultResponseProxy.getResponseProxy({
        fetchStrategy: fetchStrategies.getCacheFirstStrategy({
          serverResponseCallback: function(request, response) {
            return new Promise(function (resolve, reject) {
              resolve(response);
            })
          }
        }),
        requestHandlerOverride: {
          handlePatch: function (request) {
            if (!persistenceManager.isOnline()) {

              persistenceUtils.requestToJSON(request).then(function (data) {
                var profile = JSON.parse(data.body.text);

                persistenceManager.getCache().match(profile_request).then(function (response) {
                  persistenceUtils.setResponsePayload(response, profile).then(function (response) {
                    persistenceManager.getCache().put(profile_request, response);
                  })
                })
              })

              var init = {'status': 503, 'statusText': 'Edit will be processed when online'};
              return Promise.resolve(new Response(null, init));
            } else {
              return persistenceManager.browserFetch(request);
            }
          }
        }
      });


      // var MBEregex = /fixitfastclient\//;

      persistenceManager.init().then(function(){
        persistenceManager.register({ scope: new RegExp(MBEregex.source + /incidents(?!\/).*/.source)})
                          .then(function(registration) {
                            registration.addEventListener('fetch', function (event) {
                              if(!incidents_request)
                                incidents_request = event.request.clone();
                              event.respondWith(new Promise(function (resolve, reject) {
                                defaultIncidentsResponseProxy.processRequest(event.request.clone())
                                  .then(function (response) {
                                    resolve(addTimeStamp(event.request, response));
                                  });
                              }));
                            });
                          });
        persistenceManager.register({ scope: new RegExp(MBEregex.source + /incidents\/inc-\d{3}($|\?\_\=\d+)/.source) })
                          .then(function(registration){
                            registration.addEventListener('fetch',
                              defaultIncidentResponseProxy.getFetchEventListener()
                            );
                          });
        persistenceManager.register({ scope: new RegExp(MBEregex.source + /incidents\/inc-\d{3}\/activities$/.source) }).then(function(registration){
          registration.addEventListener('fetch', function (event) {
            event.respondWith(new Promise(function (resolve, reject) {
              defaultActResponseProxy.processRequest(event.request.clone())
                .then(function (response) {
                  resolve(addTimeStamp(event.request, response));
                }).catch(function (e) {
                  reject(e);
                });
            }))
          });
        });
        persistenceManager.register({ scope: new RegExp(MBEregex.source + /customers$/.source) }).then(function(registration){
          registration.addEventListener('fetch', function (event) {
            if(!customers_request)
              customers_request = event.request.clone();
            event.respondWith(defaultCustomersResponseProxy.getFetchEventListener()(event))
          });
        });
        persistenceManager.register({ scope: new RegExp(MBEregex.source + /customers\/cus-\d{3}$/.source) }).then(function(registration){
          registration.addEventListener('fetch', defaultCustomerResponseProxy.getFetchEventListener());
        });
        persistenceManager.register({ scope: new RegExp(MBEregex.source + /stats\?technician=/.source) }).then(function(registration){
          registration.addEventListener('fetch', defaultStatsResponseProxy.getFetchEventListener());
        });
        persistenceManager.register({ scope: new RegExp(MBEregex.source + /stats\/incidents\?technician=/.source)})
        .then(function(registration) {
          registration.addEventListener('fetch', function (event) {
            if(!incidents_stats)
              incidents_stats = event.request.clone();
            event.respondWith(new Promise(function (resolve, reject) {
              defaultIncStatsResponseProxy.processRequest(event.request.clone())
                .then(function (response) {
                  resolve(addTimeStamp(event.request, response));
                });
            }));
          });
        });
        persistenceManager.register({ scope: new RegExp(MBEregex.source + /users\/~/.source) }).then(function(registration){
          registration.addEventListener('fetch', function (event) {
            if(!profile_request)
              profile_request = event.request.clone();
            event.respondWith(defaultProfileResponseProxy.getFetchEventListener()(event))
          });

          // load user profile
          app.getUserProfileAndClearBusyContext();
        });
      });

      var count = 0;
      var preflightOptionsRequestTimeout = 30000;
      var max_sync = 5;

      self.sync = function () {
        count++;
        return persistenceManager.getSyncManager().sync({preflightOptionsRequestTimeout: preflightOptionsRequestTimeout}).then(function(result) {
          count = 0;
          return result;
        }, function(err) {
          if (err.response != null && err.response.status == 504 && count < max_sync) {
            // try again
            return self.sync();
          } else {
            count = 0;
            return Promise.reject(err);
          }
        });
      };

      self.getSyncLog = function () {
        return persistenceManager.getSyncManager().getSyncLog();
      }

      function triggerEvent (eventName, data) {
        var event = new CustomEvent(eventName, {
          detail: data
        });
        document.getElementById('page').dispatchEvent(event);
      }

      self.refreshData = function (syncLogs) {
        //if syncLog contains create incident or create customer request then
        //refreshing respective listview to sync id with server
        var state = oj.Router.rootInstance.currentState().id;
        if (state != 'incidents' && state != 'customers')
          retrun;
        syncLogs.some(function (syncLog) {
          if(syncLog.request.method == 'POST' &&
            syncLog.request.url.match(new RegExp(MBEregex.source + state + /(?!\/).*/.source))) {
              var request;
              var eventName;
              if(state == 'incidents') {
                request = incidents_request;
                eventName = 'onIncidentsUpdated';
              } else {
                request = customers_request;
                eventName = 'onCustomersUpdated';
              }
              persistenceManager.getCache()
                .match(request).then(function (cachedResponse) {
                  persistenceUtils.responseToJSON(cachedResponse).then(function (response) {
                    triggerEvent(eventName, response.body.text);
                  });
              });
              return true;
            }
        });
      }

    }

    return OfflineController;

  }

)
