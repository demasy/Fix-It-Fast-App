# Change Log for oj-sample-mobile JET pack

## Version 0.0.4-beta

* Update baseline to JET 6.2.0 and replace use of deprecated JET APIs

## 0.0.9-beta

* Forked into the oj-sample-mobile-internal pack

## 0.0.8-beta

* Property inspector improvements

## 0.0.7-beta

* Upgrade to JET 6.1.0
* Improvements to oj-sample-mobile-online-detector

## 0.0.6-beta

* Upgrade to JET 6.0.0

## 0.0.5-beta

* Correction of icon colors for VBCS use