/**
 * @license
 * Copyright (c) 2014, 2021, Oracle and/or its affiliates.
 * Licensed under The Universal Permissive License (UPL), Version 1.0
 * as shown at https://oss.oracle.com/licenses/upl/
 * @ignore
 */
/**
  Copyright (c) 2015, 2018, Oracle and/or its affiliates.
  The Universal Permissive License (UPL), Version 1.0
*/
define('oj-sample-mobile-internal/common/resources/nls/auth-error-translations-strings',{
  "root": true
});


/**
  Copyright (c) 2015, 2018, Oracle and/or its affiliates.
  The Universal Permissive License (UPL), Version 1.0
*/

define('oj-sample-mobile-internal/common/auth-error-translations',['ojL10n!./resources/nls/auth-error-translations-strings'],
  function (translations) {
    function ErrorTranslationsModel() {
      this.translations = translations;
    }

    /**
     * Method to convert error object to translated error message.
     * @param {object} error 
     */
    ErrorTranslationsModel.prototype.getTranslationForError = function(error) {
      if (error.errorSource === 'system')
        return error.translatedErrorMessage;

      var message = this.translations.errorMessages[error.errorCode];
      if (!message)
        return this.translations.errorMessages.unknownErrorCode + error.errorCode;
      return message;
    };

    return new ErrorTranslationsModel();
  }
);

//# sourceMappingURL=auth-error-translations.js.map