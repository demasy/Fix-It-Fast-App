# OJ-SAMPLE-MOBILE-INTERNAL Component Set

The oj-sample-mobile-internal JET Pack defines a set of re-usable JET components for Oracle JET and Visual Builder Cloud Service applications to use