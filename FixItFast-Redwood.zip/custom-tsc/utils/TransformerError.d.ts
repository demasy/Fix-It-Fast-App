export declare class TransformerError extends Error {
    constructor(className: string, message: string);
}
